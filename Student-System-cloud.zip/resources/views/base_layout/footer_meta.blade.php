<!-- Jquery JS-->
<script src="{{asset('asset/')}}/vendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap JS-->
<script src="{{asset('asset/')}}/vendor/bootstrap-4.1/popper.min.js"></script>
<script src="{{asset('asset/')}}/vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="{{asset('asset/')}}/vendor/slick/slick.min.js">
</script>
<script src="{{asset('asset/')}}/vendor/wow/wow.min.js"></script>
<script src="{{asset('asset/')}}/vendor/animsition/animsition.min.js"></script>
<script src="{{asset('asset/')}}/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="{{asset('asset/')}}/vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="{{asset('asset/')}}/vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="{{asset('asset/')}}/vendor/circle-progress/circle-progress.min.js"></script>
<script src="{{asset('asset/')}}/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="{{asset('asset/')}}/vendor/chartjs/Chart.bundle.min.js"></script>
<script src="{{asset('asset/')}}/vendor/select2/select2.min.js">
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- Main JS-->
<script src="{{asset('asset/')}}/js/main.js"></script>
