<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><?php echo e($course->title); ?></div>
             <div class="card-body">
             <p>Course Number : <?php echo e($course->course_number); ?></p>
             <p>Course Description : <?php echo e($course->desc); ?> </p>

             <br>
                <?php if(auth()->guard('admin')->check()): ?>
                <div class="col-md-12">

                  <div class="table-responsive table--no-card m-b-30">
                            <table class="table table-borderless table-striped table-earning">
                            <thead>
                            <tr>
                             <th>#</th>
                            <th>Student Name</th>
                            <th>Grade</th>
                            <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                 <td><?php echo e(++$index); ?></td>
                                <td><?php echo e($student->name); ?></td>
                                <td id="currentGrade" html-va><?php echo e($student->pivot->grade); ?></a></td>
                                <td>
                                <button  data-student_id = "<?php echo e($student->id); ?>" type="button" class="btn btn-primary updateGradeButton "
                                        data-toggle="modal"
                                        data-target="#gradeForm">
                                    edit
                                </button>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             </tbody>
                            </table>
                            </div>

                            </div>

                            <?php endif; ?>

                        </div>
            </div>
    </div>
</div>


<div class="modal fade" id="gradeForm" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Grade</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                    <div class="form-group col-md-9 first-div">
                    <form id="submitForm"  method = "post" action="<?php echo e(route('course.update',$course->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <input type="hidden" name="student_id" id="studentId">
                                <div class="form-group">
                                        <label class="form-control-label"> New Grade : </label>
                                        <input type="text" name="grade" id="modalGrade" class="form-control" required>
                                    </div>

                                    <input type="submit" id="submitUpdateGrade" class="btn btn-info" value="Update">
                        </form>

                    </div>

                </div>

            </div>
        </div>
    </div>


</div>

</div>

<?php $__env->startSection('script'); ?>

<script>

$('.updateGradeButton').click(function () {

    var id = $(this).data('student_id');
    $('#studentId').val(id);
    var row = $(this).closest("tr");
    var grade = row.find("#currentGrade").text();
      $('#modalGrade').val(grade);

        });


        $('#submitUpdateGrade').click(function (e) {
            e.preventDefault();
            let grade = $('#modalGrade').val();
            if (grade == '') {
                swal("please enter a grade", "", "error");
                return;
            }
            swal({
                text:
                  'Are you sure that you want to update the grade ?',
                icon: "warning",
                buttons: ["No", "Yes"],
                dangerMode: true,

            })
                .then((willSubmit) => {
                    if (willSubmit) {
                        $('#submitForm').submit();
                    }
                });
        });

</script>


<?php $__env->stopSection(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\StudentSystem\resources\views/course/show.blade.php ENDPATH**/ ?>