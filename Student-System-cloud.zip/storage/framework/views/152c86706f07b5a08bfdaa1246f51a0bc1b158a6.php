<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><?php echo e($student->name); ?> </div>
             <div class="card-body">
            <div class="col-md-12">
                    <div class=" pull-right col-md-4">
                        <div class="card-image">
                                <img  class="image-card" src="<?php echo e(asset('uploads/'.$student->image)); ?>" width="100%"  height ="300" alt="Student Image">

                        </div><br>

                    </div>

                <p>Student Number : <?php echo e($student->student_number); ?></p>
                    <p>Name : <?php echo e($student->name); ?> </p>
                    <p>Email : <?php echo e($student->email); ?></p>
                    <p>Gender : <?php echo e($student->gender ==1 ?'male':'female'); ?> </p>
                    <p>Identity Card Number : <?php echo e($student->id_card_number); ?></p>
                    <p> Date Of Birth : <?php echo e($student->dob); ?> </p>
                    <p> Balance : <?php echo e(is_null($student->balance)?'0':$student->balance); ?> </p><br>

                    <a href="#" class="btn btn-success">Print Personal Info</a>
                            <a href="#" class="btn btn-info">Print Grades</a>
                            <a href="#"class="btn btn-success">Print Finaicial Info</a>

             <br>
                </div>


           <br>

                <?php if(count($student_courses)>0): ?>

                <div class="col-md-12">
                        <div class="table-responsive table--no-card m-b-30">
                                <h3><?php echo e($student->name); ?> Grades</h3><br>

                            <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                        <tr>
                                         <th>#</th>
                                        <th>Course Code</th>
                                        <th>Course Name</th>
                                        <th>Grade</th>
                                        <th>Semester</th>
                                        <th>Year</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $student_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $sum = 0;
                                            $count=1;

                                            ?>
                                            <tr>
                                             <td><?php echo e(++$index); ?></td>
                                            <td><?php echo e($course->course_number); ?></td>
                                            <td><a href="<?php echo e(route('course.show',$course->id)); ?>"><?php echo e($course->title); ?></a></td>
                                            <td><?php echo e($course->pivot->grade); ?></td>
                                            <td><?php echo e($course->pivot->semester); ?></td>
                                            <td><?php echo e($course->pivot->year); ?></td>
                                            <?php
                                            $sum += $course->pivot->grade ;
                                                $count++;
                                            ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </tbody>

                                        </table>
                                        <p>Avarage = <?php echo e($sum/($count-1)); ?> </p>
                            </div>
            </div>


            <?php endif; ?>


            <?php if(count($student_fees)>0): ?>
            <div class="col-md-12">
            <div class="table-responsive table--no-card m-b-30">
            <h3><?php echo e($student->name); ?> Fincial Report</h3>

                            <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                    <tr>
                                     <th>#</th>
                                    <th>Fee Type</th>
                                    <th>Value</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $student_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                         <td><?php echo e(++$index); ?></td>
                                        <td><?php echo e($fee->name); ?></td>
                                       <td><?php echo e($fee->pivot->value); ?> </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                     </tbody>
                                    </table>

                                   <div class="col-md-4">
                                   <p>current balance : <?php echo e($student->balance); ?></p>
                                   <p>required balance from the student : <?php echo e($student->balance < 0 ? $student->balance : 0); ?></p>
                                   </div>
                       </div>
        </div>
                <?php endif; ?>




              </div>


            </div>



</div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\StudentSystem\resources\views/student/show.blade.php ENDPATH**/ ?>