<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Add Student</div>
            <div class="card-body">
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                     <p>   <?php echo e(session('success')); ?>   </p>
                    </div>
         <?php endif; ?>

        <div class="login-form">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            <?php endif; ?>
        <form action="<?php echo e(route('student.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Name</label>
                    <input class="au-input au-input--full" type="text" name="name" placeholder="name">
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input class="au-input au-input--full" type="email" name="email" placeholder="Email">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password">
                </div>

                <div class="form-group">
                        <label>Identity Card Number</label>
                        <input class="au-input au-input--full" type="text" name="id_card_number" placeholder="Identity Card Number">
                    </div>

                    <div class="form-group">
                            <label>Date Of Birth</label>
                            <input class="au-input au-input--full" type="date" name="dob">
                        </div>

                        <div class="form-group">
                            <label for="select" class=" form-control-label">Gender</label>
                            <select name="gender" id="select" class="form-control">
                            <option selected disabled>Select Gender</option>
                            <option value="1">Male</option>
                            <option value="2">Female</option>
                            </select>
                            </div>

                    <div class="form-group">
                            <label>Image</label>
                            <input class="au-input au-input--full form-control-file" type="file" name="image" >

                        </div>

                        <div class="form-group">
                                <label>Balance</label>
                                <input class="au-input au-input--full" type="text" name="balance" placeholder="Balance">
                            </div>





                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">register</button>

            </form>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\StudentSystem\resources\views/admin/students_create.blade.php ENDPATH**/ ?>