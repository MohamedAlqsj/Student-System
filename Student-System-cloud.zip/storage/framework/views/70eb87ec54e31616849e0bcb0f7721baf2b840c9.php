<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Students</div>
             <div class="card-body">

                <div class="col-md-12">
                <a href="<?php echo e(route('student.create')); ?>" class="btn btn-success btn" style="margin-bottom: 20px"> <i class="fa fa-plus"></i> Add Student </a>

                <div class="pull-right">
                        <form class="form-header" action="" method="GET">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="search for a student" />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                </div>
                  <div class="table-responsive table--no-card m-b-30">
                            <table class="table table-borderless table-striped table-earning">
                            <thead>
                            <tr>
                             <th>#</th>
                             <th>Student Number</th>
                            <th>Student name</th>
                            <th>Gender</th>
                            <th>Balance</th>
                            <th>Update Balance</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                 <td><?php echo e(++$index); ?></td>
                                <td><a href="<?php echo e(route('student.show',$student->id)); ?>"><?php echo e($student->student_number); ?></a></td>
                                <td><a href="<?php echo e(route('student.show',$student->id)); ?>"><?php echo e($student->name); ?></a></td>
                                <td><?php echo e($student->gender ==1 ?'male':'female'); ?></td>
                                <td id="currentBalance"><?php echo e($student->balance); ?></td>
                               <td>
                                    <form id="submitForm"  method = "post" action="<?php echo e(route('student.update',$student->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                              <input type="text" name="balance" id="modalBalance" class="form-control" required>
                               <input type="submit" id="submitUpdateBalance" class="btn btn-info" value="Update" style="margin-left: 75px">

                              </form>
                                

                        </td>
                        
                                </tr>





                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             </tbody>
                            </table>
                            <?php echo e($students->links()); ?>


                            </div>

                            </div>
            </div>
            </div>
    </div>
</div>





</div>

</div>

<?php $__env->startSection('script'); ?>

<script>

$('.updateBalanceButton').click(function () {

    var row = $(this).closest("tr");
    var balance = row.find("#currentBalance").text();
      $('#modalBalance').val(balance);

        });


        $('#submitUpdateBalance').click(function (e) {
            e.preventDefault();
            let balance = $('#modalBalance').val();
            if (balance== '') {
                swal("please enter a balance", "", "error");
                return;
            }
            swal({
                text:
                  'Are you sure that you want to update the balance ?',
                icon: "warning",
                buttons: ["No", "Yes"],
                dangerMode: true,

            })
                .then((willSubmit) => {
                    if (willSubmit) {
                        $('#submitForm').submit();
                    }
                });
        });

</script>


<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\StudentSystem\resources\views/admin/students_index.blade.php ENDPATH**/ ?>