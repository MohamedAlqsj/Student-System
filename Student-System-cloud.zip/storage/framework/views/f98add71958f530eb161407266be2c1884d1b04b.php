<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Dashboard</div>
             <div class="card-body">
             <h3>Welcome Mr <?php echo e(auth()->user()->name); ?></h3><br>

                <div class="col-md-12">

                  <div class="table-responsive table--no-card m-b-30">
                            <table class="table table-borderless table-striped table-earning">
                            <thead>
                            <tr>
                             <th>#</th>
                            <th>Course Code</th>
                            <th>Title</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                 <td><?php echo e(++$index); ?></td>
                                <td><?php echo e($course->course_number); ?></td>
                                <td><a href="<?php echo e(route('course.show',$course->id)); ?>"><?php echo e($course->title); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             </tbody>
                            </table>
                            </div>

                            </div>
            </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\StudentSystem\resources\views/admin/index.blade.php ENDPATH**/ ?>